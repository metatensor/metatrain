#!/bin/bash

mtt train options.yaml
